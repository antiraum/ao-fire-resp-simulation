/*****************************************************************
JADE - Java Agent DEvelopment Framework is a framework to develop
multi-agent systems in compliance with the FIPA specifications.
Copyright (C) 2000 CSELT S.p.A.

GNU Lesser General Public License

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation, 
version 2.1 of the License. 

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the
Free Software Foundation, Inc., 59 Temple Place - Suite 330,
Boston, MA  02111-1307, USA.
*****************************************************************/

package jade.proto.states;

//#CUSTOM_EXCLUDE_FILE

import jade.core.behaviours.*;

/**
 * This behaviour is used as a state of a FSMbehavior in order to reset 
 * some of the FSM's states or the whole FSM
 *
 * @author Giovanni Caire - TILab
 * @author Marco Monticone 
 */
public class StateResetter extends OneShotBehaviour{
  
	String[] sname;
	
  /**
   *  Constructor.
   * @param states  Represent the names of FSM's to reset. 
   * If null the parent Behaviour is resetted
   * 
   */
	public StateResetter(String[] states) {
		sname=states;
	}
	
	/**
   *  Constructor.
   *  equivalent to StateResetter(null)
   */
	public StateResetter(){
		this(null);
	}
	
	public void action() {
		Behaviour st;
		FSMBehaviour p = (FSMBehaviour)parent;
		if(sname == null){
			p.reset();
		}
		else{
			for(int i=0;i<sname.length;i++){
					st=p.getState(sname[i]);
					st.reset();
			}
		}	
	}
}
	
	
	
	

  
	

	